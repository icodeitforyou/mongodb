import { Router } from "express";
import { userModel } from "../schema/userSchema.js";
import  jwt from "jsonwebtoken";
export const siginpRoute = Router();

siginpRoute.post("/signin", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(400)
        .json({ status: false, message: "All fields are required." });
    }
    const user = await userModel.findOne({ email });
    if (!user) throw new Error("User Not Found");
    if (user.password == password) {
       const token=jwt.sign({email}, "test", { expiresIn: '1d' });
      return res.json({ status: true, message: "User Logged In Successfully", user: user, token:token });
    } else {
      throw new Error("Password Not Match");
    }
  } catch (error) {
    res.status(500).json({
      status: false,
      error: error.message,
    });
  }
});
