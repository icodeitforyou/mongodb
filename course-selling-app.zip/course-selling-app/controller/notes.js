import { Router } from "express";
import { userModel } from "../schema/userSchema.js";
import { notesModel } from "../schema/notesSchema.js";
import  jwt from "jsonwebtoken";
export const notesRouter = Router();

notesRouter.get("/notes", async (req, res) => {
  try {
    const token = req.headers['x-access-token'];
    const user=jwt.verify(token, 'test'),
    userEmail=user.email;    
    const userData = await userModel.findOne({ email:userEmail });
    let userId=userData._id
    const notes = await notesModel.find({ userId:userId });
    return res.json({ status: true, message: "Notes Fetched Successfully",notes:notes });
  } catch (error) {
    res.status(500).json({
      status: false,
      error: error.message,
    });
  }
});
