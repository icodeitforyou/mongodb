import { Router } from "express";
import { userModel } from "../schema/userSchema.js";
import  jwt from "jsonwebtoken";
export const profileRouter = Router();

profileRouter.get("/profile", async (req, res) => {
  try {
    const token = req.headers['x-access-token'];
    const user=jwt.verify(token, 'test'),
    userEmail=user.email;    
    const userData = await userModel.findOne({ email:userEmail });
      return res.json({ status: true, message: "User Logged In Successfully",user:userData });
  } catch (error) {
    res.status(500).json({
      status: false,
      error: error.message,
    });
  }
});
