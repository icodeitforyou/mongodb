import express, { Router } from "express";
import cors from "cors";
import { signUpRoute } from "./controller/signup.js";
import { dbConnect } from "./config/dbconfig.js";
import { siginpRoute } from "./controller/signin.js";
import { profileRouter } from "./controller/profile.js";
import { notesRouter } from "./controller/notes.js";
import { addNotesRouter } from "./controller/addNotes.js";

const app = express();
app.use(cors());
app.use(express.json());
const router = Router();
app.use("/", router);
router.use("/auth", signUpRoute);
router.use("/auth", siginpRoute);
router.use("/", profileRouter);
router.use("/", notesRouter);
router.use("/notes", addNotesRouter);


const PORT = 3000;
app.listen(PORT, () => {
    dbConnect();
  console.log(`Server is running on port ${PORT}`);
});
